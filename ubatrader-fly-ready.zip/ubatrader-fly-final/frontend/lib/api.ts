const API=process.env.NEXT_PUBLIC_API_URL||'http://localhost:8080/api';
function csrf(){if(typeof document==='undefined')return '';const m=document.cookie.match(/(?:^|; )ub_csrf=([^;]+)/);return m?decodeURIComponent(m[1]):''}
export async function api(path:string,options:RequestInit={}){const method=(options.method||'GET').toUpperCase();const headers=new Headers(options.headers);if(options.body && !headers.has('Content-Type'))headers.set('Content-Type','application/json');if(!['GET','HEAD','OPTIONS'].includes(method))headers.set('x-csrf-token',csrf());const r=await fetch(`${API}${path}`,{...options,headers,credentials:'include'});const data=await r.json().catch(()=>({}));if(!r.ok)throw new Error(data.message||'Request failed');return data}
export {API};
