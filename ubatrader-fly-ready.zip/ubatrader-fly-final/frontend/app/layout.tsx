import './globals.css'; import Nav from '../components/Nav';
export const metadata={title:'Ubatrader — UNIUYO Campus Commerce',description:'The campus marketplace for products, services and delivery.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <><Nav/><main>{children}</main><footer className="footer"><div className="container"><b style={{fontSize:24,color:'#fff'}}>UBATRADER</b><p>Campus commerce, services and delivery — built for UNIUYO.</p><p style={{fontSize:12}}>Secure payments powered by Paystack.</p></div></footer></>}
