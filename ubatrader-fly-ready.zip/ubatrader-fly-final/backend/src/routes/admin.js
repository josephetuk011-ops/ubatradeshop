import { Router } from 'express';
import { prisma } from '../lib/prisma.js';
import { requireAuth, requireRole, requireCsrf } from '../middleware/auth.js';

const r = Router();
r.use(requireAuth, requireRole('ADMIN'));

r.get('/overview', async (req,res,next)=>{
  try {
    const [users,products,orders,revenue] = await Promise.all([
      prisma.user.count(), prisma.product.count(), prisma.order.count({where:{status:{in:['PAID','PROCESSING','READY_FOR_PICKUP','OUT_FOR_DELIVERY','DELIVERED']}}}),
      prisma.order.aggregate({where:{status:{in:['PAID','PROCESSING','READY_FOR_PICKUP','OUT_FOR_DELIVERY','DELIVERED']}},_sum:{total:true}})
    ]);
    res.json({users,products,orders,revenue:revenue._sum.total||0});
  } catch(e){next(e)}
});

r.get('/riders', async (req,res,next)=>{
  try { res.json({riders:await prisma.riderProfile.findMany({include:{user:{select:{id:true,firstName:true,lastName:true,phone:true,email:true}}}})}); }
  catch(e){next(e)}
});

r.post('/orders/:id/assign-rider', requireCsrf, async (req,res,next)=>{
  try {
    const {riderId}=req.body;
    const rider=await prisma.user.findFirst({where:{id:riderId,role:'RIDER',riderProfile:{verified:true}}});
    if(!rider) return res.status(404).json({message:'Verified rider not found'});
    const order=await prisma.order.update({where:{id:req.params.id},data:{riderId,deliveryStatus:'ASSIGNED',status:'READY_FOR_PICKUP'}});
    res.json({order});
  } catch(e){next(e)}
});

r.post('/vendors/:userId/verify', requireCsrf, async(req,res,next)=>{
  try { const p=await prisma.vendorProfile.update({where:{userId:req.params.userId},data:{verified:true}});res.json({profile:p}); }
  catch(e){next(e)}
});

r.post('/providers/:userId/verify', requireCsrf, async(req,res,next)=>{
  try { const p=await prisma.serviceProviderProfile.update({where:{userId:req.params.userId},data:{verified:true}});res.json({profile:p}); }
  catch(e){next(e)}
});

r.post('/riders/:userId/verify', requireCsrf, async(req,res,next)=>{
  try { const p=await prisma.riderProfile.update({where:{userId:req.params.userId},data:{verified:true}});res.json({profile:p}); }
  catch(e){next(e)}
});

export default r;
