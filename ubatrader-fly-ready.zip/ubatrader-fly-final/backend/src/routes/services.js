import { Router } from 'express'; import { prisma } from '../lib/prisma.js'; import { requireAuth,requireRole,requireCsrf } from '../middleware/auth.js';
const r=Router();
r.get('/providers',async(req,res,next)=>{try{const providers=await prisma.serviceProviderProfile.findMany({where:{verified:true},include:{user:{select:{firstName:true,lastName:true}}},orderBy:{businessName:'asc'}});res.json({providers})}catch(e){next(e)}});
r.post('/requests',requireAuth,requireCsrf,async(req,res,next)=>{try{const {providerId,title,details,budget}=req.body;const x=await prisma.serviceRequest.create({data:{customerId:req.user.sub,providerId,title,details,budget:Number.isFinite(budget)?budget:undefined}});res.status(201).json({request:x})}catch(e){next(e)}});
r.get('/requests',requireAuth,async(req,res,next)=>{try{const where=req.user.role==='SERVICE_PROVIDER'?{provider:{userId:req.user.sub}}:{customerId:req.user.sub};const x=await prisma.serviceRequest.findMany({where,include:{provider:{include:{user:{select:{firstName:true,lastName:true}}}}},orderBy:{createdAt:'desc'}});res.json({requests:x})}catch(e){next(e)}});
export default r;
