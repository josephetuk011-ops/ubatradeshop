import { verifyToken } from '../lib/auth.js';
export function requireAuth(req,res,next){
  try { const token=req.cookies?.ub_access; if(!token) return res.status(401).json({message:'Authentication required'}); req.user=verifyToken(token); next(); }
  catch { return res.status(401).json({message:'Invalid or expired session'}); }
}
export function requireRole(...roles){ return (req,res,next)=> roles.includes(req.user?.role) ? next() : res.status(403).json({message:'Insufficient permissions'}); }
export function requireCsrf(req,res,next){
  if(['GET','HEAD','OPTIONS'].includes(req.method)) return next();
  const cookie=req.cookies?.ub_csrf; const header=req.get('x-csrf-token');
  if(!cookie || !header || cookie !== header) return res.status(403).json({message:'CSRF validation failed'});
  next();
}
