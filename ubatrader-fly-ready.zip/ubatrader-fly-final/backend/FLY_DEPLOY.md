# Ubatrader API — Fly.io deployment

## 1. Open the backend directory

From the extracted project:

```bash
cd ubatrader/backend
```

Run Fly commands from this directory. It contains the Dockerfile and fly.toml.

## 2. Authenticate

```bash
fly auth login
```

## 3. Create the Fly application

If `ubatrader-api` is not already registered:

```bash
fly launch --no-deploy --name ubatrader-api --region jnb
```

If the app already exists, skip `fly launch` and use:

```bash
fly deploy
```

## 4. Set secrets

Use your PostgreSQL connection string and secrets at runtime. Do not put them in `fly.toml`.

```bash
fly secrets set \
  DATABASE_URL="YOUR_POSTGRES_CONNECTION_STRING" \
  JWT_SECRET="GENERATE_A_LONG_RANDOM_SECRET" \
  JWT_EXPIRES_IN="7d" \
  FRONTEND_URL="https://YOUR-VERCEL-DOMAIN.vercel.app" \
  PAYSTACK_SECRET_KEY="YOUR_PAYSTACK_TEST_SECRET_KEY" \
  PAYSTACK_PUBLIC_KEY="YOUR_PAYSTACK_TEST_PUBLIC_KEY" \
  PAYSTACK_CURRENCY="NGN" \
  COOKIE_SECURE="true"
```

## 5. Deploy

```bash
fly deploy
```

## 6. Verify

```bash
fly status
fly logs
```

Then open:

```text
https://ubatrader-api.fly.dev/health
```

A healthy response should look like:

```json
{"ok":true,"service":"ubatrader-api","database":"up"}
```

## Important

The Dockerfile uses `prisma db push` because this initial project does not contain a Prisma migrations directory. Once the schema stabilizes, create and commit proper Prisma migrations and switch the container startup to `prisma migrate deploy` for safer production schema changes.
