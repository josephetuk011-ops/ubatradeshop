# Ubatrader

A production-oriented campus commerce starter for UNIUYO: marketplace products, vendor stores, service providers, dispatch riders, orders and Paystack payments.

## Stack
- Frontend: Next.js + React, deploy to Vercel.
- API: Node.js + Express, deploy to Railway, Render or Fly.io.
- Database: PostgreSQL + Prisma.
- Payments: Paystack server-side initialization, verification and signed webhooks.

## Local setup
1. Create PostgreSQL database.
2. Copy `backend/.env.example` to `backend/.env` and fill secrets.
3. `cd backend && npm install && npx prisma generate && npx prisma migrate dev --name init && npm run prisma:seed && npm run dev`
4. `cd frontend && npm install && npm run dev`

## Production variables
Backend: DATABASE_URL, JWT_SECRET, JWT_EXPIRES_IN, FRONTEND_URL, PAYSTACK_SECRET_KEY, PAYSTACK_CURRENCY, COOKIE_SECURE=true.
Frontend: NEXT_PUBLIC_API_URL.

Never put `PAYSTACK_SECRET_KEY`, DATABASE_URL or JWT_SECRET in `NEXT_PUBLIC_*` variables or frontend code.
