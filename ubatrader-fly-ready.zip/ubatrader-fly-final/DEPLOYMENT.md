# Ubatrader deployment

## Railway API + PostgreSQL
1. Create a Railway project.
2. Add a PostgreSQL service. Railway exposes `DATABASE_URL` and other PostgreSQL variables to services. You can reference a variable from another service with `${{Postgres.DATABASE_URL}}` (adjust `Postgres` to your service name).
3. Deploy `/backend` as the API service.
4. Set these API variables:

DATABASE_URL=${{Postgres.DATABASE_URL}}
JWT_SECRET=<32+ random characters>
JWT_EXPIRES_IN=7d
FRONTEND_URL=https://YOUR-VERCEL-DOMAIN.vercel.app
PAYSTACK_SECRET_KEY=YOUR_PAYSTACK_TEST_SECRET_KEY
PAYSTACK_PUBLIC_KEY=YOUR_PAYSTACK_TEST_PUBLIC_KEY (test) or sk_live_... (production)
PAYSTACK_CURRENCY=NGN
COOKIE_SECURE=true
NODE_ENV=production

5. Health check: `/health`.
6. Paystack webhook: `https://YOUR-API-DOMAIN/api/payments/webhook`.

## Vercel frontend
Deploy `/frontend` as a Next.js project. Set:
NEXT_PUBLIC_API_URL=https://YOUR-API-DOMAIN/api

Do not expose DATABASE_URL, JWT_SECRET or PAYSTACK_SECRET_KEY to the frontend. Never prefix those secrets with NEXT_PUBLIC_.

## Render
Deploy `/backend` using the supplied render.yaml. Add the same environment variables. Use a managed PostgreSQL database and set DATABASE_URL to its internal connection string.

## Fly.io
Deploy `/backend` using the supplied Dockerfile/fly.toml. Set secrets with `fly secrets set` rather than committing them.

## Paystack
Use test keys while testing. The secret key is server-only. Paystack initialization is done by the API, the frontend receives only the checkout URL/access code, and the API verifies successful payments and checks the verified amount before marking the order paid. Configure the webhook to `/api/payments/webhook`.
